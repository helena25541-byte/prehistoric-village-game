# Prehistoric Tribe — v0.2.1

A colorful, stylized 3D prehistoric island prototype built with Godot 4.7.2.

## v0.2.1 camera and ocean fix
- Rotates the ocean PlaneMesh onto the horizontal XZ plane.
- Aims the isometric camera after adding it to the scene tree.
- Uses a centered orthographic camera framing the island.
- Keeps landscape Android orientation and the resource HUD.

## Build
Use the repository GitHub Actions workflow at `.github/workflows/build-apk.yml`.
The Android artifact is a debug APK for testing.
