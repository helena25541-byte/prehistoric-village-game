# Prehistoric Tribe — v0.3.0

A code-first Godot 4.7.2 mobile island-village prototype.

## v0.3.0 changes
- Added a stylized waterfall and rocky pool.
- Added a friendly baby dinosaur with a gently swaying tail.
- Added an egg nest, fruit details, and a pebble path.
- Added a build-hut action costing 15 wood and 8 stone.
- Kept the fixed isometric camera, landscape orientation, and resource controls.

## Build
Use the repository GitHub Actions workflow at `.github/workflows/build-apk.yml`.
The Android export preset is named `Android`.

This is an early prototype. The environment uses procedural primitive meshes;
it is not yet a finished commercial game.
