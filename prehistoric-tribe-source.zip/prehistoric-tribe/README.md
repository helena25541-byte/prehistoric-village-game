# Prehistoric Tribe — Prototype 0.1

Fresh original Godot 4.7.2 project. This is an early playable 3D isometric village prototype.

## Included
- Fixed orthographic/isometric camera
- Stylized island, grass, sandy shore and surrounding water
- Procedurally generated trees, rocks and bushes
- Two primitive huts and a campfire
- Placeholder tribe member
- Basic wood, stone and food collection buttons

All visuals are generated from built-in Godot meshes; no third-party game assets are included.

## Open locally
Open `project.godot` with Godot 4.7.2 and press Play.

## Scope
This is a prototype, not a finished commercial game. Character animation, detailed art, touch controls, saving, quests, construction and Android export are future milestones.

Inspired by the broad prehistoric village-building genre, without copying The Croods' characters, maps, names, art, sounds or proprietary assets.
