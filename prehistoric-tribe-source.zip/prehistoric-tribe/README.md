# Prehistoric Tribe — Version 0.2.0

A code-first Godot 4.7.2 Android prototype with a fixed isometric camera and landscape orientation.

## Version 0.2.0
- Reworked colorful, cartoon-style island environment.
- Rounded grassy island with sandy shore and surrounding water.
- Three prehistoric huts, campfire, fence, trees, rocks, bushes and flowers.
- Stylized tribe members and a friendly island bird.
- Resource collection UI for wood, stone and food.

## Build
The repository GitHub Actions workflow downloads Godot 4.7.2 and matching Android export templates, then exports a debug APK.
