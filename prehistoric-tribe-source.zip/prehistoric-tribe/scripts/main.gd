extends Node3D

const TREE_COUNT := 42
const ROCK_COUNT := 22
var rng := RandomNumberGenerator.new()
var wood := 0
var stone := 0
var food := 0
var resource_label: Label
var status_label: Label

func _ready() -> void:
	rng.randomize()
	build_environment()
	build_island()
	scatter_nature()
	build_village()
	build_player()
	build_ui()
	update_ui()

func mat(c: Color, rough: float = 1.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	return m

func add_mesh(mesh: Mesh, material: Material, pos: Vector3, scl: Vector3 = Vector3.ONE, parent: Node = self) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.mesh = mesh
	n.material_override = material
	n.position = pos
	n.scale = scl
	parent.add_child(n)
	return n

func build_environment() -> void:
	var env_node := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.16, 0.43, 0.72)
	sky_mat.sky_horizon_color = Color(0.72, 0.85, 0.92)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.75, 0.82, 0.86)
	env.ambient_light_energy = 0.7
	env_node.environment = env
	add_child(env_node)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -32, 0)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	add_child(sun)

	var water := PlaneMesh.new()
	water.size = Vector2(100, 100)
	add_mesh(water, mat(Color(0.06, 0.43, 0.62), 0.25), Vector3(0, -1.5, 0))

	var cam := Camera3D.new()
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.size = 43.0
	cam.position = Vector3(27, 31, 34)
	cam.look_at(Vector3.ZERO, Vector3.UP)
	add_child(cam)
	cam.current = true

func build_island() -> void:
	var base := SphereMesh.new()
	add_mesh(base, mat(Color(0.40, 0.25, 0.14)), Vector3(0, -0.45, 0), Vector3(17, 2.6, 14))
	var grass := SphereMesh.new()
	add_mesh(grass, mat(Color(0.29, 0.56, 0.20)), Vector3(0, 0.48, 0), Vector3(16.6, 1.0, 13.7))
	for i in range(48):
		var a := TAU * float(i) / 48.0
		var sand := SphereMesh.new()
		sand.radius = 0.55
		sand.height = 0.25
		add_mesh(sand, mat(Color(0.82, 0.70, 0.43)), Vector3(cos(a) * 16.2, 0.25, sin(a) * 13.2), Vector3(1, 0.45, 1))

func random_point(margin: float = 2.0) -> Vector3:
	var a := rng.randf_range(0.0, TAU)
	var r := sqrt(rng.randf()) * (17.0 - margin)
	return Vector3(cos(a) * r, 1.0, sin(a) * r * 0.78)

func build_tree(p: Vector3, s: float) -> void:
	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.18 * s
	trunk.bottom_radius = 0.28 * s
	trunk.height = 1.7 * s
	add_mesh(trunk, mat(Color(0.34, 0.19, 0.09)), p + Vector3(0, 0.85 * s, 0))
	var crown := SphereMesh.new()
	crown.height = 1.8
	var greens := [Color(0.12, 0.39, 0.16), Color(0.19, 0.49, 0.18), Color(0.28, 0.56, 0.20)]
	add_mesh(crown, mat(greens[rng.randi_range(0, 2)]), p + Vector3(0, 2.0 * s, 0), Vector3(1.15, 1, 1.05) * s)
	var crown2 := SphereMesh.new()
	crown2.radius = 0.72
	add_mesh(crown2, mat(Color(0.31, 0.61, 0.22)), p + Vector3(0.48 * s, 2.2 * s, 0.1 * s), Vector3.ONE * s * 0.8)

func build_rock(p: Vector3, s: float) -> void:
	var rock := SphereMesh.new()
	rock.height = 1.5
	var colors := [Color(0.43, 0.46, 0.43), Color(0.55, 0.52, 0.44), Color(0.35, 0.39, 0.38)]
	var n := add_mesh(rock, mat(colors[rng.randi_range(0, 2)]), p + Vector3(0, 0.45 * s, 0), Vector3(s, s * 0.72, s * 0.82))
	n.rotation_degrees.y = rng.randf_range(0, 360)

func scatter_nature() -> void:
	for i in range(TREE_COUNT):
		build_tree(random_point(3.0), rng.randf_range(0.72, 1.25))
	for i in range(ROCK_COUNT):
		build_rock(random_point(2.5), rng.randf_range(0.55, 1.15))
	for i in range(28):
		var bush := SphereMesh.new()
		bush.radius = 0.6
		bush.height = 0.9
		add_mesh(bush, mat(Color(0.22, 0.47, 0.16)), random_point(2.0) + Vector3(0, 0.25, 0), Vector3(1.2, 0.7, 1))

func build_hut(p: Vector3) -> void:
	var body := BoxMesh.new()
	body.size = Vector3(3, 2, 2.5)
	add_mesh(body, mat(Color(0.66, 0.39, 0.19)), p + Vector3(0, 1, 0))
	var roof := PrismMesh.new()
	roof.size = Vector3(3.6, 1.5, 3)
	add_mesh(roof, mat(Color(0.38, 0.22, 0.12)), p + Vector3(0, 2.55, 0), Vector3(1, 0.8, 1))

func build_village() -> void:
	build_hut(Vector3(-4, 1, 1))
	build_hut(Vector3(1.5, 1, -3))
	var ring := CylinderMesh.new()
	ring.top_radius = 0.8
	ring.bottom_radius = 0.8
	ring.height = 0.25
	add_mesh(ring, mat(Color(0.35, 0.25, 0.17)), Vector3(0, 1.2, 3))
	var flame := SphereMesh.new()
	flame.height = 1.1
	add_mesh(flame, mat(Color(1.0, 0.36, 0.06), 0.4), Vector3(0, 1.85, 3), Vector3(0.65, 1.1, 0.65))

func build_player() -> void:
	var person := Node3D.new()
	person.name = "TribeMember"
	person.position = Vector3(4, 1, 3)
	add_child(person)
	var body := CapsuleMesh.new()
	body.height = 1.9
	add_mesh(body, mat(Color(0.86, 0.58, 0.28)), Vector3(0, 1, 0), Vector3.ONE, person)
	var head := SphereMesh.new()
	head.radius = 0.43
	add_mesh(head, mat(Color(0.92, 0.69, 0.46)), Vector3(0, 2.05, 0), Vector3.ONE, person)
	var hair := SphereMesh.new()
	hair.radius = 0.46
	add_mesh(hair, mat(Color(0.19, 0.12, 0.08)), Vector3(0, 2.35, -0.04), Vector3(1, 0.55, 1), person)

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var panel := PanelContainer.new()
	panel.position = Vector2(18, 16)
	panel.size = Vector2(340, 100)
	layer.add_child(panel)
	var box := VBoxContainer.new()
	panel.add_child(box)
	resource_label = Label.new()
	resource_label.add_theme_font_size_override("font_size", 22)
	box.add_child(resource_label)
	status_label = Label.new()
	status_label.text = "Welcome to your prehistoric island!"
	box.add_child(status_label)
	var row := HBoxContainer.new()
	row.position = Vector2(18, 130)
	layer.add_child(row)
	for item in ["Collect wood", "Collect stone", "Collect food"]:
		var button := Button.new()
		button.text = item
		if item == "Collect wood":
			button.pressed.connect(collect_wood)
		elif item == "Collect stone":
			button.pressed.connect(collect_stone)
		else:
			button.pressed.connect(collect_food)
		row.add_child(button)

func collect_wood() -> void:
	wood += 5
	status_label.text = "You collected 5 wood!"
	update_ui()

func collect_stone() -> void:
	stone += 3
	status_label.text = "You collected 3 stone!"
	update_ui()

func collect_food() -> void:
	food += 4
	status_label.text = "You collected 4 food!"
	update_ui()

func update_ui() -> void:
	if is_instance_valid(resource_label):
		resource_label.text = "Wood: %d   Stone: %d   Food: %d" % [wood, stone, food]
