extends Node3D

const ISLAND_X := 13.8
const ISLAND_Z := 10.8
const TREE_COUNT := 30
const ROCK_COUNT := 15

var rng := RandomNumberGenerator.new()
var wood := 35
var stone := 27
var food := 20
var resource_label: Label
var status_label: Label
var dinosaur_tail: Node3D
var dinosaur_time: float = 0.0
var huts_built: int = 3

func _process(delta: float) -> void:
    dinosaur_time += delta
    if is_instance_valid(dinosaur_tail):
        dinosaur_tail.rotation.z = sin(dinosaur_time * 2.2) * 0.16

func _ready() -> void:
    rng.randomize()
    build_world()
    build_island()
    build_village()
    scatter_nature()
    build_characters()
    build_waterfall()
    build_dinosaur(Vector3(-8.0, 0.95, 3.8), 1.0)
    build_extra_details()
    build_interface()
    update_resources()

func material(color: Color, roughness: float = 1.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func mesh_node(mesh: Mesh, color: Color, position: Vector3, scale: Vector3 = Vector3.ONE, parent: Node = self, rotation: Vector3 = Vector3.ZERO) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.mesh = mesh
    node.material_override = material(color)
    node.position = position
    node.scale = scale
    node.rotation_degrees = rotation
    parent.add_child(node)
    return node

func box(size: Vector3, color: Color, position: Vector3, parent: Node = self, rotation: Vector3 = Vector3.ZERO) -> MeshInstance3D:
    var m := BoxMesh.new()
    m.size = size
    return mesh_node(m, color, position, Vector3.ONE, parent, rotation)

func sphere(color: Color, position: Vector3, scale: Vector3, parent: Node = self) -> MeshInstance3D:
    var m := SphereMesh.new()
    m.radius = 1.0
    m.height = 2.0
    return mesh_node(m, color, position, scale, parent)

func cylinder(top: float, bottom: float, height: float, color: Color, position: Vector3, parent: Node = self) -> MeshInstance3D:
    var m := CylinderMesh.new()
    m.top_radius = top
    m.bottom_radius = bottom
    m.height = height
    return mesh_node(m, color, position, Vector3.ONE, parent)

func build_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.16, 0.48, 0.82)
    sky_mat.sky_horizon_color = Color(0.72, 0.88, 0.98)
    sky_mat.ground_bottom_color = Color(0.20, 0.39, 0.48)
    sky_mat.ground_horizon_color = Color(0.58, 0.73, 0.77)
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.82, 0.88, 0.95)
    env.ambient_light_energy = 0.85
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52, -28, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)

    var water_mesh := PlaneMesh.new()
    water_mesh.size = Vector2(180, 180)
    mesh_node(water_mesh, Color(0.04, 0.48, 0.70), Vector3(0, -1.65, 0))

    var camera := Camera3D.new()
    camera.projection = Camera3D.PROJECTION_ORTHOGONAL
    camera.size = 32.0
    camera.position = Vector3(25, 30, 31)
    add_child(camera)
    camera.look_at(Vector3(0, 0.5, 0), Vector3.UP)
    camera.current = true

func build_island() -> void:
    # Rounded dark earth underside and bright grassy top.
    sphere(Color(0.39, 0.22, 0.12), Vector3(0, -0.55, 0), Vector3(14.2, 1.65, 11.2))
    sphere(Color(0.31, 0.66, 0.25), Vector3(0, 0.20, 0), Vector3(13.9, 0.92, 10.95))

    # Sandy shoreline ring made from many small rounded stones.
    for i in range(72):
        var angle := TAU * float(i) / 72.0
        var p := Vector3(cos(angle) * 13.45, -0.02, sin(angle) * 10.55)
        sphere(Color(0.91, 0.75, 0.46), p, Vector3(0.48, 0.22, 0.43))

    # A few bright flower patches and stepping stones.
    for i in range(22):
        var p := random_island_point(8.5)
        sphere(Color(0.95, 0.78, 0.26), p + Vector3(0, 0.05, 0), Vector3(0.20, 0.10, 0.20))

func random_island_point(radius: float = 10.0) -> Vector3:
    var angle := rng.randf_range(0.0, TAU)
    var r := sqrt(rng.randf()) * radius
    return Vector3(cos(angle) * r, 0.95, sin(angle) * r * 0.77)

func build_tree(p: Vector3, size: float = 1.0) -> void:
    cylinder(0.22 * size, 0.34 * size, 1.7 * size, Color(0.43, 0.24, 0.12), p + Vector3(0, 0.85 * size, 0))
    var greens: Array[Color] = [Color(0.10, 0.43, 0.20), Color(0.17, 0.55, 0.22), Color(0.25, 0.63, 0.25)]
    sphere(greens[rng.randi_range(0, greens.size() - 1)], p + Vector3(0, 2.0 * size, 0), Vector3(1.05, 1.15, 1.0) * size)
    sphere(Color(0.30, 0.69, 0.28), p + Vector3(0.55 * size, 2.12 * size, 0.10 * size), Vector3(0.72, 0.78, 0.72) * size)
    sphere(Color(0.22, 0.58, 0.22), p + Vector3(-0.52 * size, 1.92 * size, 0.12 * size), Vector3(0.76, 0.80, 0.75) * size)

func build_rock(p: Vector3, size: float) -> void:
    var colors: Array[Color] = [Color(0.49, 0.53, 0.52), Color(0.62, 0.59, 0.50), Color(0.39, 0.45, 0.46)]
    sphere(colors[rng.randi_range(0, colors.size() - 1)], p + Vector3(0, 0.40 * size, 0), Vector3(size, 0.72 * size, 0.82 * size))
    sphere(Color(0.72, 0.72, 0.65), p + Vector3(-0.18 * size, 0.65 * size, -0.12 * size), Vector3(0.38 * size, 0.25 * size, 0.34 * size))

func build_bush(p: Vector3) -> void:
    sphere(Color(0.18, 0.48, 0.18), p + Vector3(0, 0.35, 0), Vector3(0.78, 0.58, 0.70))
    sphere(Color(0.27, 0.61, 0.22), p + Vector3(0.42, 0.38, 0.08), Vector3(0.48, 0.48, 0.48))
    sphere(Color(0.95, 0.36, 0.28), p + Vector3(0.10, 0.72, 0.05), Vector3(0.16, 0.16, 0.16))

func build_hut(p: Vector3, body_color: Color, roof_color: Color, scale_factor: float = 1.0) -> void:
    var hut := Node3D.new()
    hut.position = p
    hut.scale = Vector3.ONE * scale_factor
    add_child(hut)
    cylinder(1.15, 1.35, 1.8, body_color, Vector3(0, 0.95, 0), hut)
    var roof := PrismMesh.new()
    roof.size = Vector3(3.1, 1.7, 3.0)
    mesh_node(roof, roof_color, Vector3(0, 2.25, 0), Vector3.ONE, hut)
    box(Vector3(0.82, 1.25, 0.16), Color(0.25, 0.13, 0.08), Vector3(0, 0.70, 1.16), hut)
    sphere(Color(0.98, 0.73, 0.28), Vector3(0, 2.92, 0), Vector3(0.14, 0.22, 0.14), hut)

func build_village() -> void:
    build_hut(Vector3(-4.1, 0.95, 1.2), Color(0.79, 0.49, 0.25), Color(0.53, 0.28, 0.15), 1.0)
    build_hut(Vector3(2.0, 0.95, -3.4), Color(0.84, 0.58, 0.31), Color(0.63, 0.34, 0.17), 0.82)
    build_hut(Vector3(5.2, 0.95, 2.5), Color(0.72, 0.43, 0.23), Color(0.43, 0.25, 0.14), 0.72)

    # Village fire pit and logs.
    cylinder(0.90, 1.0, 0.24, Color(0.40, 0.31, 0.23), Vector3(-0.2, 1.05, 3.8))
    var fire_log := cylinder(0.13, 0.13, 1.5, Color(0.34, 0.18, 0.09), Vector3(-0.2, 1.30, 3.8), self)
    fire_log.rotation_degrees.z = 90
    sphere(Color(1.0, 0.39, 0.06), Vector3(-0.2, 1.72, 3.8), Vector3(0.34, 0.58, 0.34))
    sphere(Color(1.0, 0.76, 0.16), Vector3(-0.2, 1.72, 3.8), Vector3(0.16, 0.38, 0.16))

    # Small wooden fence around the central camp.
    for i in range(7):
        var x := -2.8 + float(i) * 0.85
        cylinder(0.07, 0.09, 0.75, Color(0.43, 0.25, 0.12), Vector3(x, 1.25, 5.3))
    box(Vector3(5.4, 0.12, 0.12), Color(0.52, 0.31, 0.15), Vector3(-0.25, 1.45, 5.3))

func scatter_nature() -> void:
    for i in range(TREE_COUNT):
        var p := random_island_point(10.8)
        if Vector2(p.x, p.z).length() > 5.0:
            build_tree(p, rng.randf_range(0.72, 1.18))
    for i in range(ROCK_COUNT):
        var p := random_island_point(10.5)
        build_rock(p, rng.randf_range(0.45, 0.95))
    for i in range(24):
        build_bush(random_island_point(10.0))

func make_person(p: Vector3, tunic: Color, hair_color: Color) -> void:
    var person := Node3D.new()
    person.position = p
    add_child(person)
    var body := CapsuleMesh.new()
    body.radius = 0.38
    body.height = 1.45
    mesh_node(body, tunic, Vector3(0, 0.95, 0), Vector3.ONE, person)
    sphere(Color(0.88, 0.63, 0.43), Vector3(0, 1.95, 0), Vector3(0.40, 0.43, 0.38), person)
    sphere(hair_color, Vector3(0, 2.23, -0.08), Vector3(0.43, 0.30, 0.40), person)
    var arm := cylinder(0.08, 0.08, 0.75, Color(0.30, 0.18, 0.10), Vector3(0.48, 1.10, 0), person)
    arm.rotation_degrees.z = 35

func build_characters() -> void:
    make_person(Vector3(4.0, 0.95, 4.0), Color(0.91, 0.49, 0.18), Color(0.20, 0.11, 0.07))
    make_person(Vector3(-6.0, 0.95, -2.5), Color(0.24, 0.56, 0.72), Color(0.25, 0.15, 0.08))
    make_person(Vector3(0.5, 0.95, -6.0), Color(0.72, 0.31, 0.35), Color(0.15, 0.10, 0.08))

    # Friendly round dodo-like island bird.
    sphere(Color(0.30, 0.39, 0.73), Vector3(7.0, 1.40, -1.0), Vector3(0.58, 0.65, 0.48))
    sphere(Color(0.34, 0.44, 0.79), Vector3(7.0, 2.0, -1.0), Vector3(0.38, 0.38, 0.36))
    sphere(Color(1.0, 0.67, 0.18), Vector3(7.30, 1.95, -0.78), Vector3(0.25, 0.12, 0.15))
    sphere(Color(0.08, 0.08, 0.08), Vector3(7.13, 2.08, -0.68), Vector3(0.055, 0.055, 0.055))


func build_waterfall() -> void:
    # A small rocky waterfall on the back edge of the island.
    var cliff := sphere(Color(0.40, 0.43, 0.39), Vector3(0.0, 1.05, -8.1), Vector3(3.0, 1.25, 1.25))
    cliff.rotation_degrees.z = -8
    sphere(Color(0.28, 0.53, 0.24), Vector3(0.0, 2.15, -8.0), Vector3(2.0, 0.34, 0.9))
    var fall := box(Vector3(1.45, 2.4, 0.12), Color(0.18, 0.72, 0.88, 0.86), Vector3(0.0, 0.05, -7.35))
    fall.material_override.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    sphere(Color(0.24, 0.79, 0.88), Vector3(0.0, -0.95, -6.75), Vector3(1.55, 0.12, 0.72))
    # Rocks and plants frame the water.
    for i in range(5):
        var x := -2.1 + float(i) * 1.05
        build_rock(Vector3(x, 0.95, -7.8 + rng.randf_range(-0.35, 0.35)), rng.randf_range(0.45, 0.72))
        if i % 2 == 0:
            build_bush(Vector3(x + 0.25, 0.95, -8.7))

func build_dinosaur(p: Vector3, size: float = 1.0) -> void:
    var dino := Node3D.new()
    dino.position = p
    dino.scale = Vector3.ONE * size
    add_child(dino)
    # Friendly, round baby dinosaur.
    sphere(Color(0.25, 0.68, 0.39), Vector3(0, 0.95, 0), Vector3(0.95, 0.78, 1.12), dino)
    sphere(Color(0.31, 0.76, 0.45), Vector3(0.0, 1.62, 0.62), Vector3(0.70, 0.66, 0.70), dino)
    sphere(Color(0.96, 0.82, 0.54), Vector3(0.0, 1.35, 1.12), Vector3(0.48, 0.30, 0.25), dino)
    sphere(Color(0.06, 0.08, 0.06), Vector3(-0.25, 1.78, 1.16), Vector3(0.075, 0.09, 0.07), dino)
    sphere(Color(0.06, 0.08, 0.06), Vector3(0.25, 1.78, 1.16), Vector3(0.075, 0.09, 0.07), dino)
    # Tail pivots so it can sway gently.
    dinosaur_tail = Node3D.new()
    dinosaur_tail.position = Vector3(0, 1.05, -0.92)
    dino.add_child(dinosaur_tail)
    sphere(Color(0.22, 0.60, 0.34), Vector3(0, 0, -0.68), Vector3(0.35, 0.34, 0.95), dinosaur_tail)
    # Small back spikes.
    for i in range(4):
        var spike := CylinderMesh.new()
        spike.top_radius = 0.0
        spike.bottom_radius = 0.20
        spike.height = 0.38
        mesh_node(spike, Color(0.95, 0.67, 0.24), Vector3(0, 1.68, -0.50 + float(i) * 0.40), Vector3.ONE, dino)

func build_extra_details() -> void:
    # Fruit trees and a tiny egg nest add points of interest.
    for i in range(8):
        var p := random_island_point(8.7)
        sphere(Color(0.94, 0.28, 0.16), p + Vector3(0.18, 1.55, 0.0), Vector3(0.14, 0.16, 0.14))
    cylinder(0.72, 0.88, 0.16, Color(0.48, 0.31, 0.17), Vector3(6.0, 1.02, -5.0))
    for i in range(3):
        sphere(Color(0.94, 0.84, 0.60), Vector3(5.55 + float(i) * 0.42, 1.20, -5.0), Vector3(0.22, 0.28, 0.20))
    # Pebble path leading from the camp toward the waterfall.
    for i in range(8):
        var z := 4.2 - float(i) * 1.35
        var x := 0.3 + sin(float(i) * 0.55) * 1.2
        sphere(Color(0.76, 0.68, 0.53), Vector3(x, 1.02, z), Vector3(0.42, 0.09, 0.30))

func build_player_hut() -> void:
    if wood < 15 or stone < 8:
        status_label.text = "Need 15 wood and 8 stone to build a hut."
        return
    wood -= 15
    stone -= 8
    var hut_positions := [
        Vector3(-7.0, 0.95, 0.0),
        Vector3(7.0, 0.95, 4.0),
        Vector3(4.0, 0.95, -6.0),
        Vector3(-3.0, 0.95, -5.5)
    ]
    var p: Vector3 = hut_positions[(huts_built - 3) % hut_positions.size()]
    build_hut(p, Color(0.79, 0.52, 0.29), Color(0.66, 0.31, 0.16), 0.72)
    huts_built += 1
    status_label.text = "New hut built! Your village is growing."
    update_resources()

func build_interface() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)

    var panel := PanelContainer.new()
    panel.position = Vector2(20, 18)
    panel.custom_minimum_size = Vector2(420, 104)
    layer.add_child(panel)
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.10, 0.18, 0.24, 0.88)
    style.set_corner_radius_all(18)
    style.content_margin_left = 18
    style.content_margin_right = 18
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    panel.add_theme_stylebox_override("panel", style)

    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 7)
    panel.add_child(column)
    resource_label = Label.new()
    resource_label.add_theme_font_size_override("font_size", 23)
    resource_label.add_theme_color_override("font_color", Color(1.0, 0.95, 0.80))
    column.add_child(resource_label)
    status_label = Label.new()
    status_label.text = "Welcome to the island, chief!"
    status_label.add_theme_font_size_override("font_size", 16)
    status_label.add_theme_color_override("font_color", Color(0.86, 0.94, 0.96))
    column.add_child(status_label)

    var actions := HBoxContainer.new()
    actions.position = Vector2(20, 140)
    actions.add_theme_constant_override("separation", 10)
    layer.add_child(actions)
    add_action_button(actions, "🪵  Wood +5", collect_wood)
    add_action_button(actions, "🪨  Stone +3", collect_stone)
    add_action_button(actions, "🍎  Food +4", collect_food)

    var build_actions := HBoxContainer.new()
    build_actions.position = Vector2(20, 198)
    build_actions.add_theme_constant_override("separation", 10)
    layer.add_child(build_actions)
    add_action_button(build_actions, "🏠  Build hut (15🪵 8🪨)", build_player_hut)

    var title := Label.new()
    title.text = "PREHISTORIC ISLAND  •  VILLAGE 0.3.2"
    title.position = Vector2(20, 255)
    title.add_theme_font_size_override("font_size", 17)
    title.add_theme_color_override("font_color", Color(1.0, 0.94, 0.73))
    layer.add_child(title)

func add_action_button(parent: HBoxContainer, text_value: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = text_value
    button.custom_minimum_size = Vector2(150, 48)
    button.add_theme_font_size_override("font_size", 16)
    button.pressed.connect(callback)
    parent.add_child(button)

func collect_wood() -> void:
    wood += 5
    status_label.text = "You gathered 5 pieces of wood!"
    update_resources()

func collect_stone() -> void:
    stone += 3
    status_label.text = "You found 3 useful stones!"
    update_resources()

func collect_food() -> void:
    food += 4
    status_label.text = "You collected 4 tasty fruits!"
    update_resources()

func update_resources() -> void:
    if is_instance_valid(resource_label):
        resource_label.text = "🪵 %d     🪨 %d     🍎 %d" % [wood, stone, food]
